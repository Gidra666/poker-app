from textual.app import App, ComposeResult
from textual.widgets import Input, Static, Button
from textual.containers import Vertical

from treys import Card, Deck, Evaluator

evaluator = Evaluator()

# -------- PARSE --------

def parse_cards(card_str):

    cards = []

    if card_str == "-" or card_str == "":
        return cards

    for i in range(0, len(card_str), 2):

        cards.append(
            Card.new(card_str[i:i+2])
        )

    return cards


def random_hand(deck):

    return [
        deck.draw(1)[0],
        deck.draw(1)[0]
    ]


# -------- EQUITY --------

def calculate_equity(hero, board, players):

    hero_cards = parse_cards(hero)
    board_cards = parse_cards(board)

    wins = 0
    ties = 0

    simulations = 6000

    for _ in range(simulations):

        deck = Deck()

        for c in hero_cards:
            if c in deck.cards:
                deck.cards.remove(c)

        for c in board_cards:
            if c in deck.cards:
                deck.cards.remove(c)

        opponents = []

        for _ in range(players - 1):

            opponents.append(
                random_hand(deck)
            )

        current_board = list(board_cards)

        while len(current_board) < 5:

            current_board.append(
                deck.draw(1)[0]
            )

        hero_score = evaluator.evaluate(
            current_board,
            hero_cards
        )

        opp_scores = []

        for opp in opponents:

            opp_scores.append(
                evaluator.evaluate(
                    current_board,
                    opp
                )
            )

        best = min(opp_scores)

        if hero_score < best:

            wins += 1

        elif hero_score == best:

            ties += 1

    return (wins + ties * 0.5) / simulations


# -------- APP --------

class PokerGUI(App):

    def compose(self) -> ComposeResult:

        yield Vertical(

            Static("MTT Analyzer"),

            Input(
                placeholder="Hand (AhKs)",
                id="hand"
            ),

            Input(
                placeholder="Board (- если нет)",
                id="board"
            ),

            Input(
                placeholder="Players (2)",
                id="players"
            ),

            Input(
                placeholder="Pot (10)",
                id="pot"
            ),

            Input(
                placeholder="Call (5)",
                id="call"
            ),

            Input(
                placeholder="Stack bb (25)",
                id="stack"
            ),

            Button(
                "CALCULATE",
                id="calc"
            ),

            Static(
                "",
                id="result"
            )

        )


    def on_button_pressed(self, event):

        try:

            hand = self.query_one("#hand").value

            board = self.query_one("#board").value

            players = int(
                self.query_one("#players").value
            )

            pot = float(
                self.query_one("#pot").value
            )

            call = float(
                self.query_one("#call").value
            )

            stack = float(
                self.query_one("#stack").value
            )

            equity = calculate_equity(
                hand,
                board,
                players
            )

            required = call / (pot + call)

            ev = (
                equity * (pot + call)
            ) - call

            spr = stack / pot

            result_text = (
                f"Equity: {round(equity*100,2)} %\n"
                f"Required: {round(required*100,2)} %\n"
                f"EV: {round(ev,2)}\n"
                f"SPR: {round(spr,2)}"
            )

            self.query_one("#result").update(
                result_text
            )

        except:

            self.query_one("#result").update(
                "Ошибка ввода"
            )


if __name__ == "__main__":

    PokerGUI().run()
